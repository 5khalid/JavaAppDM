module project.Main {
    requires javafx.controls;
	requires poi;
	requires javafx.base;
	requires java.desktop;
    opens project to javafx.graphics,javafx.base;
}