package project;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.scene.Scene;
import javafx.scene.SubScene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

public class App extends Application {

	@Override
	public void start(Stage stage) {
		int width = 800;
		int height = 200;
		Label projectLabel = new Label("Project ID");
		Label projectNameText = new Label("");
		Label durationLabel = new Label("Duration:");
		Label durationText = new Label("");
		
		Button btn = new Button("Select");

		TableView table = new TableView();
		TableColumn columnLastName = new TableColumn("Project id");
		TableColumn columnEmail = new TableColumn("Stage");
		table.getColumns().addAll(columnLastName, columnEmail);
		table.setPrefSize(230, 200);
		ProjectCollection projects = new ProjectCollection();
		ObservableList<Project> data = FXCollections.observableArrayList();
		data.addAll(projects.getProjects());

		columnLastName.setCellValueFactory(new PropertyValueFactory<>("customerProjectID"));
		columnEmail.setCellValueFactory(new PropertyValueFactory<>("stage"));

		table.setItems(data);

		columnLastName.setPrefWidth(100);
		columnEmail.setPrefWidth(50);

		table.setTranslateX(10);
		table.setTranslateY(20);
		HBox topBox = new HBox();
		HBox leftBox = new HBox();

		int dis = width - (2 * 10) / (30 * 3) + 1;
		Line horizhontalAxis = new Line(10, 10 * 3, width - (2 * 10), 10 * 3);
		horizhontalAxis.setStroke(Color.RED);
		horizhontalAxis.setStartX(30 * 120 + dis);
		horizhontalAxis.setEndX(30 * 130 + dis);
		horizhontalAxis.setTranslateY(200);


		topBox.getChildren().addAll(projectLabel, projectNameText,durationLabel,durationText, btn);

		btn.setOnAction(e -> {
			int index = table.getSelectionModel().getSelectedIndex();
			if (index < 0)
				return;
			projectNameText.setText(projects.get(index).getCustomerProjectID());
			durationText.setText(String.valueOf(projects.get(index).duration()));
		});
		leftBox.getChildren().addAll(table);

		projectLabel.setTranslateX(250);
		projectLabel.setTranslateY(100);
		projectNameText.setTranslateX(275);
		projectNameText.setTranslateY(100);
		
		durationLabel.setTranslateX(250);
		durationLabel.setTranslateY(150);
		durationText.setTranslateX(275);
		durationText.setTranslateY(150);
				
		btn.setTranslateX(250);
		btn.setTranslateY(50);
		//
		BorderPane layoutOne = new BorderPane();
		layoutOne.setTop(topBox);
		layoutOne.setLeft(leftBox);

		SubScene subSceneOne = new SubScene(new TimeLine(width, height, 10, DataSet.BOARDS), width, height);
		layoutOne.setCenter(subSceneOne);

		Scene mainScene = new Scene(layoutOne, 2000, 1000);
		stage.setScene(mainScene);
		stage.show();

	}

	public static void main(String[] args) {
		launch();
	}
}