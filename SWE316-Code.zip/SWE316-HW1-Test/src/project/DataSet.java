package project;

import static java.util.Map.entry;

//import sample.piheaders.definition.PiBoardVersion;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public enum DataSet {
	BOARDS(3000, 3060, getPi());

	private final int startYear;
	private final int endYear;
	private final Map<Integer, String> entries;

	DataSet(int startYear, int endYear, Map<Integer, String> entries) {
		this.startYear = startYear;
		this.endYear = endYear;
		this.entries = entries;
	}

	public int getStartYear() {
		return startYear;
	}

	public int getEndYear() {
		return endYear;
	}

	public Map<Integer, String> getEntries() {
		return this.entries;
	}

	private static Map<Integer, String> getPi() {
		Map<Integer, String> entries = new HashMap<>();

		// Add new line to better align on the drawing
		for (Entry<Integer, String> entry : entries.entrySet()) {
			entry.setValue(entry.getValue() + "\n ");
		}

		return entries;
	}
}
