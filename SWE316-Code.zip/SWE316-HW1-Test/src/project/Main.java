package project;

import java.io.IOException;

public class Main {
	public static ProjectCollection projects;
	public static StageCollection stages;

	
	public static void main(String[] args) {
		try {
			projects = ReadExcelFiles.setProjects();
			stages = ReadExcelFiles.setStages();
			App.main(args);
		} catch (IOException e) {
			System.out.println("File Not Found.");
		}
	}
}