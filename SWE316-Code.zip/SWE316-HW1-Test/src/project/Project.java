package project;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Project {
	private String nodeID ;
	private String customerProjectID;
	private double stage;
	
	private Date startDate;
	private Date endDate;
	private String createdOn;
	private String ChangedOn;
	
	private double customer;
	private String currency;
	
	public Project() {

	}
	
	public String getNodeID() {
		return nodeID;
	}
	public void setNodeID(String nodeID) {
		this.nodeID = nodeID;
	}
	
	public String getCustomerProjectID() {
		return customerProjectID;
	}
	public void setCustomerProjectID(String customerProjectID) {
		this.customerProjectID = customerProjectID;
	}
	
	public double getStage() {
		return stage;
	}
	public void setStage(double stage) {
		this.stage = stage;
	}
	
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	
	public String getChangedOn() {
		return ChangedOn;
	}
	public void setChangedOn(String changedOn) {
		ChangedOn = changedOn;
	}
	
	public double getCustomer() {
		return customer;
	}
	public void setCustomer(double customer) {
		this.customer = customer;
	}
	
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	public long duration() {
		long daysDifference = 0;

		if (startDate.compareTo(endDate) > 0) {
			long dateBefore = endDate.getTime();
			long dateAfter = startDate.getTime();
			long timeDifference = Math.abs(dateAfter - dateBefore);
			daysDifference = TimeUnit.DAYS.convert(timeDifference, TimeUnit.MILLISECONDS);
		} else if (startDate.compareTo(endDate) < 0) {
			long dateBefore = startDate.getTime();
			long dateAfter = endDate.getTime();
			long timeDiff = Math.abs(dateAfter - dateBefore);
			daysDifference = TimeUnit.DAYS.convert(timeDiff, TimeUnit.MILLISECONDS);
		} else if (startDate.compareTo(endDate) == 0) {
			daysDifference = 0;
		}
		return daysDifference;
	}

}
