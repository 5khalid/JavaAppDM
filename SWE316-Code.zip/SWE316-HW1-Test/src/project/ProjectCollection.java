package project;

import java.util.ArrayList;

public class ProjectCollection {
	private static ArrayList<Project> projects = new ArrayList<Project>();

	public ProjectCollection() {
	}

	public void add(Project project) {
		projects.add(project);
	}

	public Project get(int index) {
		return projects.get(index);
	}
	
	public ArrayList<Project> getProjects() {
		return  projects;
	}
	
	public Project getByID(String id) {
		for (Project tmp : projects) {
			if (tmp.getNodeID().equals(id))
				return tmp;
		}
		return null;
	}
}
