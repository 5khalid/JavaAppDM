package project;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;


import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row; 

public class ReadExcelFiles {


	public static ProjectCollection setProjects() throws IOException {
		//obtaining input bytes from a file  
		FileInputStream fis=new FileInputStream(new File("C:\\Samples\\Projects.xls"));  

		//creating workbook instance that refers to .xls file  
		HSSFWorkbook wb=new HSSFWorkbook(fis);

		//creating a Sheet object to retrieve the object  
		HSSFSheet sheet=wb.getSheetAt(0); 

		//evaluating cell type   
		FormulaEvaluator formulaEvaluator=wb.getCreationHelper().createFormulaEvaluator();


		//ProjectCollection myProjects = new ProjectCollection();
		ProjectCollection projects = new ProjectCollection();
		for(Row row: sheet)     //iteration over row using for each loop  
		{
			Project temp = new Project();
			for(Cell cell: row)    //iteration over cell using for each loop  
			{
				switch(formulaEvaluator.evaluateInCell(cell).getCellType())  
				{  
				case Cell.CELL_TYPE_NUMERIC:   //field that represents numeric cell type   
					if(cell != null) {
						if(cell.getColumnIndex() == 2) 
							temp.setStage(cell.getNumericCellValue());
						else if(cell.getColumnIndex() == 3)
							temp.setStartDate(cell.getDateCellValue());
						else if(cell.getColumnIndex() == 4)
							temp.setEndDate(cell.getDateCellValue());
						else if(cell.getColumnIndex() == 5)
							temp.setCustomer(cell.getNumericCellValue());
					}
					break;

				case Cell.CELL_TYPE_STRING:    //field that represents string cell type  
					//getting the value of the cell as a string 
					if(cell != null) {
						if(cell.getColumnIndex() == 0)
							temp.setNodeID(cell.getStringCellValue());
						else if(cell.getColumnIndex() == 1)
							temp.setCustomerProjectID(cell.getStringCellValue());
						else if(cell.getColumnIndex() == 6)
							temp.setCurrency(cell.getStringCellValue());
						else if(cell.getColumnIndex() == 7)
							temp.setCreatedOn(cell.getStringCellValue());
						else if(cell.getColumnIndex() == 8)
							temp.setChangedOn(cell.getStringCellValue());
					}	
					break;
				}  
			}
			if (row.getRowNum() == 0)
				continue;
			projects.add(temp);
		}
		return projects;
	}



	public static StageCollection setStages() throws IOException{
		//obtaining input bytes from a file  
		FileInputStream fis=new FileInputStream(new File("C:\\Samples\\Stages.xls"));  

		//creating workbook instance that refers to .xls file  
		HSSFWorkbook wb=new HSSFWorkbook(fis);

		//creating a Sheet object to retrieve the object  
		HSSFSheet sheet=wb.getSheetAt(0); 

		//evaluating cell type   
		FormulaEvaluator formulaEvaluator=wb.getCreationHelper().createFormulaEvaluator();




		//obtaining input bytes from a file  
		FileInputStream fis2=new FileInputStream(new File("C:\\Samples\\Stages_Detailed.xls"));  

		//creating workbook instance that refers to .xls file  
		HSSFWorkbook wb2=new HSSFWorkbook(fis2);

		//creating a Sheet object to retrieve the object  
		HSSFSheet sheet2=wb2.getSheetAt(0); 

		//evaluating cell type   
		FormulaEvaluator formulaEvaluator2=wb2.getCreationHelper().createFormulaEvaluator();
		
		StageCollection stages = new StageCollection();
		for(Row row: sheet)     //iteration over row using for each loop  
		{
			Stage temp = new Stage();
			for(Cell cell: row)    //iteration over cell using for each loop  
			{
				if (row.getRowNum() == 0)
					continue;
				temp.setDate(sheet2.getRow(row.getRowNum()).getCell(2).toString());
				temp.setLanguageKey(sheet2.getRow(row.getRowNum()).getCell(4).getStringCellValue());
				sheet2.getRow(row.getRowNum()).getCell(3).setCellType(Cell.CELL_TYPE_STRING);
				temp.setTime(DateUtil.getJavaDate(Double.parseDouble(sheet2.getRow(row.getRowNum()).getCell(3).getStringCellValue())));
				
				switch(formulaEvaluator.evaluateInCell(cell).getCellType())  
				{  
				case Cell.CELL_TYPE_NUMERIC:   //field that represents numeric cell type   
					if(cell != null) {
						if(cell.getColumnIndex() == 1)
							temp.setDocumentNumber(cell.getNumericCellValue());
						else if(cell.getColumnIndex() == 4)
							temp.setTextFlag(cell.getNumericCellValue());
						else if(cell.getColumnIndex() == 5)
							temp.setNewValue(cell.getNumericCellValue());
						else if(cell.getColumnIndex() == 6)
							temp.setOldValue(cell.getNumericCellValue());
					}
					break;

				case Cell.CELL_TYPE_STRING:    //field that represents string cell type  
					//getting the value of the cell as a string 
					if(cell != null) {
						if(cell.getColumnIndex() == 0)
							temp.setObjectValue(cell.getStringCellValue());
						else if(cell.getColumnIndex() == 2)
							temp.setFieldName(cell.getStringCellValue());
						else if(cell.getColumnIndex() == 3)
							temp.setChangeIndicator(cell.getStringCellValue());		
					}	
					break;
				}

			}
			if (row.getRowNum() == 0)
				continue;
			stages.add(temp);
		}
		return stages;

	}
}  

