package project;

import java.util.Date;

public class Stage {
	private String objectValue ;
	private double documentNumber;
	private String fieldName;
	private String changeIndicator;
	
	private double textFlag;
	private double newValue;
	private double oldValue;
	
	private String date;
	private Date time;	
	private String languageKey;
	
	
	public String getObjectValue() {
		return objectValue;
	}
	public void setObjectValue(String objectValue) {
		this.objectValue = objectValue;
	}
	
	public double getDocumentNumber() {
		return documentNumber;
	}
	public void setDocumentNumber(double documentNumber) {
		this.documentNumber = documentNumber;
	}
	
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	
	public String getChangeIndicator() {
		return changeIndicator;
	}
	public void setChangeIndicator(String changeIndicator) {
		this.changeIndicator = changeIndicator;
	}
	
	public double getTextFlag() {
		return textFlag;
	}
	public void setTextFlag(double textFlag) {
		this.textFlag = textFlag;
	}
	
	public double getNewValue() {
		return newValue;
	}
	public void setNewValue(double newValue) {
		this.newValue = newValue;
	}
	
	public double getOldValue() {
		return oldValue;
	}
	public void setOldValue(double oldValue) {
		this.oldValue = oldValue;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	
	public String getLanguageKey() {
		return languageKey;
	}
	public void setLanguageKey(String languageKey) {
		this.languageKey = languageKey;
	}


}
