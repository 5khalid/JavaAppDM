package project;
import java.util.ArrayList;

public class StageCollection {
	private static ArrayList<Stage> stages = new ArrayList<Stage>();

	StageCollection() {
	}

	public void add(Stage stage) {
		stages.add(stage);
	}

	public Stage get(int index) {
		return stages.get(index);
	}

	public Stage[] getByID(String objectValue) {
		ArrayList<Stage> tmpList = new ArrayList<Stage>();
		
		for (Stage tmp : stages) {
			if (tmp.getObjectValue().equals(objectValue))
				tmpList.add(tmp);
		}
		return (Stage[]) tmpList.toArray();
	}
}
