package project;

import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.transform.Rotate;

public class TimeLine extends Pane {
	public TimeLine(int width, int height, int offset, DataSet dataSet) {
		// Set the background color
		this.setStyle("-fx-background-color: #ffffff");

		// Draw the main line from left to right
		int axisLength = width - (2 * offset);

		Line haxile = new Line(offset, offset * 3, axisLength, offset * 3);
		haxile.setStroke(Color.DARKGREY);
		haxile.setStrokeWidth(5);
		// Draw the year lines

		int month = 3;
		int yearsToDraw = (30 * month) + 1;
		double distanceBetweenYears = axisLength / yearsToDraw;
		Line horizhontalAxis = new Line(100, 10 * 3, width - (2 * 10), 10 * 3);
		horizhontalAxis.setStroke(Color.RED);
		horizhontalAxis.setTranslateY(600);
		this.getChildren().addAll(horizhontalAxis);
		this.getChildren().add(haxile);
		for (int i = 0; i < yearsToDraw; i++) {
			int currentYear = dataSet.getStartYear() + i;
			double yearLineX = (offset * 3) + (i * distanceBetweenYears);
			Line yearLine = new Line(yearLineX, offset * 2, yearLineX, offset * 4);
			yearLine.setStroke(Color.DARKGREY);
			if (currentYear % 30 == 0)
				yearLine.setStrokeWidth(4);
			else
				yearLine.setStrokeWidth(2);
			this.getChildren().add(yearLine);

			String mon = "feb";
			if (currentYear % 30 == 0) {
				Label yearLabel = new Label(mon);
				yearLabel.setLayoutX(yearLineX - 20);
				yearLabel.setLayoutY(offset * 5);
				this.getChildren().add(yearLabel);
			}

			// Add a special notation
			String notation = dataSet.getEntries().get(currentYear);

			if (notation != null && !notation.isEmpty()) {
				Line notationLine = new Line(yearLineX, offset * 5, yearLineX, offset * 9);
				notationLine.setStroke(Color.RED);
				notationLine.setStrokeWidth(3);
				this.getChildren().add(notationLine);

				int notationLabelWidth = height - (offset * 9);

				Label notationLabel = new Label(String.valueOf(dataSet.getStartYear() + i) + " - " + notation);
				notationLabel.setLayoutX(yearLineX);
				notationLabel.setLayoutY((offset * 9));
				notationLabel.setPrefWidth(notationLabelWidth);
				notationLabel.setPrefHeight(40);
				notationLabel.setStyle("-fx-font-size: 14px; -fx-text-alignment: left;");
				notationLabel.getTransforms().add(new Rotate(70, 0, 20 / 2, 0, Rotate.Z_AXIS));
				this.getChildren().add(notationLabel);
			}
		}
	}
}